# MenusApp Premium v3.0.0

Plataforma de gestión digital de restaurantes.

## Instalación

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Características

- ✅ Dashboard en tiempo real
- ✅ Gestión de menú
- ✅ Control de órdenes
- ✅ Analytics
- ✅ Responsive design
- ✅ Totalmente gratis

---

Hecho con ❤️ por MenusApp
