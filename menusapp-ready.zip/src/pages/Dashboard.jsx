import { useNavigate } from 'react-router-dom'

export default function Dashboard() {
  const navigate = useNavigate()
  
  return (
    <div style={{minHeight: '100vh', background: '#f5f5f5', padding: '40px'}}>
      <div style={{maxWidth: '1200px', margin: '0 auto'}}>
        <button 
          onClick={() => navigate('/')}
          style={{marginBottom: '30px', padding: '10px 20px', backgroundColor: '#F5581A', color: 'white', border: 'none', borderRadius: '5px', cursor: 'pointer'}}
        >
          ← Volver
        </button>
        
        <h1 style={{fontSize: '36px', fontWeight: 'bold', marginBottom: '30px'}}>📊 Dashboard</h1>
        
        <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '20px'}}>
          {[
            { label: 'Órdenes Totales', value: '1,234', color: '#F5581A' },
            { label: 'Ingresos', value: '$12,456', color: '#10b981' },
            { label: 'Clientes', value: '892', color: '#3b82f6' },
            { label: 'Rating', value: '4.8 ⭐', color: '#f59e0b' },
          ].map((stat, i) => (
            <div key={i} style={{background: 'white', padding: '20px', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)'}}>
              <p style={{color: '#666', fontSize: '14px', marginBottom: '10px'}}>{stat.label}</p>
              <p style={{fontSize: '28px', fontWeight: 'bold', color: stat.color}}>{stat.value}</p>
            </div>
          ))}
        </div>

        <div style={{marginTop: '40px', background: 'white', padding: '30px', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)'}}>
          <h2 style={{fontSize: '24px', fontWeight: 'bold', marginBottom: '20px'}}>¡Bienvenido a MenusApp!</h2>
          <p style={{fontSize: '16px', color: '#666', lineHeight: '1.6'}}>
            Esta es tu aplicación de gestión de restaurantes. Aquí puedes:
          </p>
          <ul style={{marginTop: '15px', color: '#666', fontSize: '16px', lineHeight: '1.8'}}>
            <li>📋 Gestionar tu menú digital</li>
            <li>📦 Controlar inventario</li>
            <li>📊 Ver estadísticas en tiempo real</li>
            <li>👥 Gestionar empleados</li>
            <li>💰 Procesar pagos</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
