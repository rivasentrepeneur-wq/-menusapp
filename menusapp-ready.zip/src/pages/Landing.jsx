import { useNavigate } from 'react-router-dom'

export default function Landing() {
  const navigate = useNavigate()
  
  return (
    <div style={{minHeight: '100vh', background: 'linear-gradient(to bottom, #fff9f5, #fff)'}}>
      <div style={{maxWidth: '1200px', margin: '0 auto', padding: '40px 20px', textAlign: 'center'}}>
        <div style={{fontSize: '60px', marginBottom: '20px'}}>🍽️</div>
        <h1 style={{fontSize: '48px', fontWeight: 'bold', marginBottom: '10px', color: '#1a1a1a'}}>
          MenusApp Premium
        </h1>
        <p style={{fontSize: '20px', color: '#666', marginBottom: '30px'}}>
          Gestión digital de restaurantes
        </p>
        
        <div style={{display: 'flex', gap: '20px', justifyContent: 'center', marginBottom: '60px'}}>
          <button 
            onClick={() => navigate('/dashboard')}
            style={{
              padding: '15px 40px',
              fontSize: '18px',
              backgroundColor: '#F5581A',
              color: 'white',
              border: 'none',
              borderRadius: '8px',
              cursor: 'pointer',
              fontWeight: 'bold',
              boxShadow: '0 4px 15px rgba(245, 88, 26, 0.3)'
            }}
            onMouseOver={(e) => e.target.style.backgroundColor = '#e04910'}
            onMouseOut={(e) => e.target.style.backgroundColor = '#F5581A'}
          >
            Acceder al Dashboard
          </button>
        </div>

        <div style={{display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))', gap: '30px', marginTop: '60px'}}>
          {[
            { icon: '⚡', title: 'Ultra Rápido', desc: 'Carga en menos de 1 segundo' },
            { icon: '📱', title: 'Responsive', desc: 'Funciona en todos los dispositivos' },
            { icon: '🔒', title: 'Seguro', desc: 'Encriptación de nivel empresarial' },
            { icon: '📊', title: 'Analytics', desc: 'Datos en tiempo real' },
          ].map((item, i) => (
            <div key={i} style={{padding: '20px', background: 'white', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)'}}>
              <div style={{fontSize: '40px', marginBottom: '10px'}}>{item.icon}</div>
              <h3 style={{fontSize: '18px', fontWeight: 'bold', marginBottom: '8px'}}>{item.title}</h3>
              <p style={{color: '#666', fontSize: '14px'}}>{item.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
